//
// Copyright (c) 2025-2026 @nyashiki
//
// This software is licensed under the MIT license.
// For details, see the LICENSE file in the root of this repository.
//
// SPDX-License-Identifier: MIT
//

#ifndef NSHOGI_CORE_MOVELIST_H
#define NSHOGI_CORE_MOVELIST_H

#include "types.h"
#include <algorithm>
#include <cstddef>

namespace nshogi {
namespace core {

namespace internal {

class MoveGeneratorInternal;

} // namespace internal

struct MoveList {
 public:
    MoveList()
        : Tail(Moves) {
    }

    MoveList(MoveList&& Other) noexcept {
        Tail = Moves + Other.size();
        std::copy(Other.Moves, Other.Moves + Other.size(), Moves);
    }

    MoveList(const MoveList&) = delete;
    MoveList& operator=(const MoveList&) = delete;
    MoveList& operator=(MoveList&&) = delete;

    inline Move32* begin() noexcept {
        return Moves;
    }

    inline Move32* end() noexcept {
        return Tail;
    }

    inline const Move32* begin() const noexcept {
        return Moves;
    }

    inline const Move32* end() const noexcept {
        return Tail;
    }

    inline Move32 operator[](std::size_t Index) const noexcept {
        return Moves[Index];
    }

    inline Move32& operator[](std::size_t Index) noexcept {
        return Moves[Index];
    }

    inline const Move32* find(Move32 Move) const {
        for (const auto& EachMove : *this) {
            if (EachMove == Move) {
                return &EachMove;
            }
        }

        return end();
    }

    inline std::size_t size() const noexcept {
        return (std::size_t)(Tail - Moves);
    }

 private:
    static constexpr std::size_t MoveCountMax = 600;

    alignas(32) Move32 Moves[MoveCountMax];
    Move32* Tail;

    friend class nshogi::core::internal::MoveGeneratorInternal;
};

} // namespace core
} // namespace nshogi

#endif // #ifndef NSHOGI_CORE_MOVELIST_H
