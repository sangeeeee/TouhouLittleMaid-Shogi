//
// Copyright (c) 2025-2026 @nyashiki
//
// This software is licensed under the MIT license.
// For details, see the LICENSE file in the root of this repository.
//
// SPDX-License-Identifier: MIT
//

#include "initializer.h"
#include "internal/bitboard.h"
#include "types.h"

#include <mutex>

namespace nshogi {
namespace core {
namespace initializer {

void initializeAll() {
    static_assert(std::is_trivially_copyable_v<Move32>,
                  "Move32 must be trivially copyable.");

    static std::mutex Mutex;
    // Enter the critical section here to ensure that multiple threads
    // cannot call initializeAll() concurrently.
    // This can occur, for example, when `cargo test`
    // calls this C++ code through the Rust API.
    std::lock_guard<std::mutex> Lock(Mutex);

    static bool IsCalled = false;

    if (IsCalled) {
        return;
    }

    internal::bitboard::initializeBitboards();
    IsCalled = true;
}

} // namespace initializer
} // namespace core
} // namespace nshogi
