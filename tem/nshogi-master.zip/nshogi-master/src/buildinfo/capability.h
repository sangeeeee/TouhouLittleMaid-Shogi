//
// Copyright (c) 2025-2026 @nyashiki
//
// This software is licensed under the MIT license.
// For details, see the LICENSE file in the root of this repository.
//
// SPDX-License-Identifier: MIT
//

#ifndef NSHOGI_CAPABILITY_H
#define NSHOGI_CAPABILITY_H

namespace nshogi {
namespace build_info {
namespace capability {

bool sse41Available();
bool avxAvailable();
bool avx2Available();
bool neonAvailable();

} // namespace capability
} // namespace build_info
} // namespace nshogi

#endif // #ifndef NSHOGI_CAPABILITY_H
